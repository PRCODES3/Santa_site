
console.log("Step 2 build loaded — PWA, lookup, reindeer certificates included.");
