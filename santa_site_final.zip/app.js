
let chatCount = 0;
document.getElementById('startChat').onclick = () => {
    document.querySelector('.hero').classList.add('hidden');
    document.getElementById('chatScreen').classList.remove('hidden');
};

document.getElementById('userInput').addEventListener('keypress', function(e){
    if(e.key === 'Enter'){
        chatCount++;
        if(chatCount > 2){
            document.getElementById('upgradeModal').classList.remove('hidden');
        }
    }
});
