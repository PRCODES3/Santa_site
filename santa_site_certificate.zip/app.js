
document.getElementById('certificateBtn').onclick = () => {
    document.getElementById('hero').classList.add('hidden');
    document.getElementById('certificateScreen').classList.remove('hidden');
};

document.getElementById('certMessage').onchange = function(){
    if(this.value === "custom"){
        document.getElementById('customMsg').classList.remove('hidden');
    } else {
        document.getElementById('customMsg').classList.add('hidden');
    }
};

document.getElementById('generateCert').onclick = () => {
    const name = document.getElementById('certName').value || "Buddy";
    let message = document.getElementById('certMessage').value;
    if(message === "custom"){
        message = document.getElementById('customMsg').value || "for being amazing this year";
    }

    const canvas = document.getElementById('certCanvas');
    const ctx = canvas.getContext('2d');

    // Background
    ctx.fillStyle = "#fff9e6";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.fillStyle = "#016b35";
    ctx.font = "48px serif";
    ctx.fillText("NICE LIST CERTIFICATE", 150, 80);

    ctx.font = "36px serif";
    ctx.fillText(name, 300, 200);

    ctx.font = "28px serif";
    ctx.fillText(message, 220, 260);

    const date = new Date().toLocaleDateString();
    ctx.font = "20px serif";
    ctx.fillText("Awarded: " + date, 320, 320);

    ctx.fillText("North Pole Workshop No. 1225-A", 250, 360);

    // Placeholder QR Box
    ctx.strokeRect(650, 450, 120, 120);
    ctx.font = "14px serif";
    ctx.fillText("QR Code", 665, 520);

    document.getElementById('downloadCert').classList.remove('hidden');
};

document.getElementById('downloadCert').onclick = () => {
    const canvas = document.getElementById('certCanvas');
    const link = document.createElement('a');
    link.download = "nice-list-certificate.png";
    link.href = canvas.toDataURL();
    link.click();
};
