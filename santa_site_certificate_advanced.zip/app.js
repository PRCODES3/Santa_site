
function getUniqueID(){
    return 'NP-' + Math.random().toString(36).substr(2, 9).toUpperCase();
}

document.getElementById('certificateBtn').onclick = () => {
    document.getElementById('hero').classList.add('hidden');
    document.getElementById('emailScreen').classList.remove('hidden');
};

document.getElementById('confirmEmail').onclick = () => {
    document.getElementById('emailScreen').classList.add('hidden');
    document.getElementById('certificateScreen').classList.remove('hidden');
};

document.getElementById('certMessage').onchange = function(){
    if(this.value === "custom"){
        document.getElementById('customMsg').classList.remove('hidden');
    } else {
        document.getElementById('customMsg').classList.add('hidden');
    }
};

document.getElementById('generateCert').onclick = () => {
    const name = document.getElementById('certName').value || "Buddy";
    let message = document.getElementById('certMessage').value;
    if(message === "custom"){
        message = document.getElementById('customMsg').value || "for being amazing this year";
    }

    const canvas = document.getElementById('certCanvas');
    const ctx = canvas.getContext('2d');

    ctx.fillStyle = "#fff9e6";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.fillStyle = "#d4a017";
    ctx.font = "56px serif";
    ctx.fillText("NICE LIST CERTIFICATE", 120, 80);

    ctx.fillStyle = "#5a080c";
    ctx.font = "42px serif";
    ctx.fillText(name, 300, 200);

    ctx.font = "28px serif";
    ctx.fillText(message, 200, 260);

    const date = new Date().toLocaleDateString();
    ctx.font = "20px serif";
    ctx.fillText("Awarded: " + date, 320, 320);

    const id = getUniqueID();
    ctx.fillText("Certificate ID: " + id, 290, 360);

    ctx.fillText("North Pole Workshop No. 1225-A", 250, 400);

    ctx.font = "32px cursive";
    ctx.fillText("Santa Claus", 320, 500);

    ctx.strokeStyle = "#d4a017";
    ctx.lineWidth = 4;
    ctx.strokeRect(650, 450, 120, 120);
    ctx.fillText("QR Code", 665, 520);

    document.getElementById('downloadCert').classList.remove('hidden');
};

document.getElementById('downloadCert').onclick = () => {
    const canvas = document.getElementById('certCanvas');
    const link = document.createElement('a');
    link.download = "nice-list-certificate.png";
    link.href = canvas.toDataURL();
    link.click();
};

document.getElementById('elfCertBtn').onclick = () => {
    document.getElementById('hero').classList.add('hidden');
    document.getElementById('elfScreen').classList.remove('hidden');
};

document.getElementById('generateElfCert').onclick = () => {
    const name = document.getElementById('elfName').value || "Elf Helper";
    const canvas = document.getElementById('elfCanvas');
    const ctx = canvas.getContext('2d');

    ctx.fillStyle = "#e8fff1";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.fillStyle = "#016b35";
    ctx.font = "48px serif";
    ctx.fillText("ELF ACHIEVEMENT AWARD", 120, 80);

    ctx.fillStyle = "#5a080c";
    ctx.font = "42px serif";
    ctx.fillText(name, 300, 200);

    ctx.font = "28px serif";
    ctx.fillText("for outstanding holiday assistance", 180, 260);

    const date = new Date().toLocaleDateString();
    ctx.font = "20px serif";
    ctx.fillText("Awarded: " + date, 320, 320);

    const id = getUniqueID();
    ctx.fillText("Elf ID: " + id, 320, 360);

    ctx.font = "32px cursive";
    ctx.fillText("Santa Claus", 320, 500);

    document.getElementById('downloadElf').classList.remove('hidden');
};

document.getElementById('downloadElf').onclick = () => {
    const canvas = document.getElementById('elfCanvas');
    const link = document.createElement('a');
    link.download = "elf-achievement-certificate.png";
    link.href = canvas.toDataURL();
    link.click();
};
