
let badgeCount = 0;
let certCount = 0;
let vmCount = 0;
let currentLang = "en-US";

document.getElementById('badgeBtn').onclick = () => {
    document.getElementById('hero').classList.add('hidden');
    document.getElementById('badgeScreen').classList.remove('hidden');
};

document.querySelectorAll('.badge').forEach(btn => {
    btn.onclick = () => {
        const badgeName = btn.dataset.badge;
        badgeCount++;
        document.getElementById('badgeCount').textContent = "Badges earned: " + badgeCount;

        const canvas = document.getElementById('badgeCanvas');
        const ctx = canvas.getContext('2d');
        ctx.fillStyle = "#e8fff1";
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = "#016b35";
        ctx.font = "36px serif";
        ctx.fillText("ELF BADGE AWARDED", 120, 80);
        ctx.fillStyle = "#5a080c";
        ctx.font = "28px serif";
        ctx.fillText(badgeName, 150, 180);

        document.getElementById('downloadBadge').classList.remove('hidden');
    };
});

document.getElementById('downloadBadge').onclick = () => {
    const canvas = document.getElementById('badgeCanvas');
    const link = document.createElement('a');
    link.download = "elf-badge.png";
    link.href = canvas.toDataURL();
    link.click();
};

document.getElementById('dashboardBtn').onclick = () => {
    document.getElementById('hero').classList.add('hidden');
    document.getElementById('dashboardScreen').classList.remove('hidden');
    document.getElementById('certCount').textContent = "Certificates generated: " + certCount;
    document.getElementById('badgeCount').textContent = "Badges earned: " + badgeCount;
    document.getElementById('vmCount').textContent = "Voicemails played: " + vmCount;
};

document.getElementById('languageBtn').onclick = () => {
    document.getElementById('hero').classList.add('hidden');
    document.getElementById('languageScreen').classList.remove('hidden');
};

document.querySelectorAll('.lang').forEach(btn => {
    btn.onclick = () => {
        currentLang = btn.dataset.lang;
        const utter = new SpeechSynthesisUtterance("Ho Ho Ho! Santa's voice language has been changed!");
        utter.lang = currentLang;
        speechSynthesis.speak(utter);
    };
});
