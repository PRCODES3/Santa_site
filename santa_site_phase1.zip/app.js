
document.getElementById('certificateBtn').onclick = () => {
    document.getElementById('hero').classList.add('hidden');
    document.getElementById('emailGate').classList.remove('hidden');
};

document.getElementById('confirmEmail').onclick = () => {
    document.getElementById('emailGate').classList.add('hidden');
    document.getElementById('certificateScreen').classList.remove('hidden');
};

document.getElementById('generateCert').onclick = () => {
    const name = document.getElementById('certName').value || "Buddy";
    const canvas = document.getElementById('certCanvas');
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = "#fff9e6";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "#d4a017";
    ctx.font = "56px serif";
    ctx.fillText("NICE LIST CERTIFICATE", 120, 80);
    ctx.fillStyle = "#5a080c";
    ctx.font = "42px serif";
    ctx.fillText(name, 300, 200);
    document.getElementById('downloadCert').classList.remove('hidden');
};

document.getElementById('downloadCert').onclick = () => {
    const canvas = document.getElementById('certCanvas');
    const link = document.createElement('a');
    link.download = "nice-list-certificate.png";
    link.href = canvas.toDataURL();
    link.click();
};

document.getElementById('voicemailBtn').onclick = () => {
    document.getElementById('hero').classList.add('hidden');
    document.getElementById('emailGate').classList.remove('hidden');
};

document.getElementById('confirmEmail').onclick = () => {
    document.getElementById('emailGate').classList.add('hidden');
    document.getElementById('voicemailScreen').classList.remove('hidden');
};

document.getElementById('playVM').onclick = () => {
    const name = document.getElementById('vmName').value || "buddy";
    const msg = document.getElementById('vmText').value || "Santa is proud of you!";
    const utter = new SpeechSynthesisUtterance(`Ho Ho Ho! Hello ${name}! ${msg}`);
    speechSynthesis.speak(utter);
};
