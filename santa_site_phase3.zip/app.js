
const themes = {
    christmas: {
        title: "Santa Nice List Certificate",
        bg: "#fff9e6",
        textColor: "#b5121b"
    },
    newyear: {
        title: "New Year Fairy Wish Certificate",
        bg: "#e0e8ff",
        textColor: "#001d6d"
    },
    easter: {
        title: "Easter Bunny Kindness Award",
        bg: "#fffbe8",
        textColor: "#7a4e00"
    },
    tooth: {
        title: "Tooth Fairy Sparkle Certificate",
        bg: "#e8fff9",
        textColor: "#006b5b"
    },
    birthday: {
        title: "Birthday Genie Celebration Certificate",
        bg: "#fff0ff",
        textColor: "#7a007a"
    }
};

document.querySelectorAll('.themeBtn').forEach(btn => {
    btn.onclick = () => {
        const themeKey = btn.dataset.theme;
        const theme = themes[themeKey];
        document.getElementById('hero').classList.add('hidden');
        document.getElementById('themeScreen').classList.remove('hidden');
        document.getElementById('themeTitle').textContent = theme.title;
        document.body.style.background = theme.bg;
        document.body.style.color = theme.textColor;
    };
});

document.getElementById('generateThemeCert').onclick = () => {
    const name = document.getElementById('themeName').value || "Friend";
    const canvas = document.getElementById('themeCanvas');
    const ctx = canvas.getContext('2d');

    ctx.fillStyle = "#fff";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.fillStyle = "#000";
    ctx.font = "48px serif";
    ctx.fillText("Certificate Awarded To:", 200, 150);

    ctx.font = "40px serif";
    ctx.fillText(name, 320, 250);

    document.getElementById('downloadTheme').classList.remove('hidden');
};

document.getElementById('downloadTheme').onclick = () => {
    const canvas = document.getElementById('themeCanvas');
    const link = document.createElement('a');
    link.download = "seasonal-certificate.png";
    link.href = canvas.toDataURL();
    link.click();
};
