
document.getElementById('certificateBtn').onclick = () => {
    document.getElementById('hero').classList.add('hidden');
    document.getElementById('certificateScreen').classList.remove('hidden');
};

document.getElementById('generateCert').onclick = () => {
    const name = document.getElementById('certName').value || "Buddy";
    const canvas = document.getElementById('certCanvas');
    const ctx = canvas.getContext('2d');

    ctx.fillStyle = "#fff9e6";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.fillStyle = "#d4a017";
    ctx.font = "56px serif";
    ctx.fillText("NICE LIST CERTIFICATE", 120, 80);

    ctx.fillStyle = "#5a080c";
    ctx.font = "42px serif";
    ctx.fillText(name, 300, 200);

    const date = new Date().toLocaleDateString();
    ctx.font = "20px serif";
    ctx.fillText("Awarded: " + date, 320, 260);

    ctx.font = "20px serif";
    ctx.fillText("North Pole Workshop No. 1225-A", 250, 300);

    const qrCanvas = document.createElement('canvas');
    QRCode.toCanvas(qrCanvas, "https://example.com/santa", function () {
        ctx.drawImage(qrCanvas, 650, 450, 120, 120);
    });

    document.getElementById('downloadCert').classList.remove('hidden');
    document.getElementById('downloadPDF').classList.remove('hidden');
    document.getElementById('printCert').classList.remove('hidden');
};

document.getElementById('downloadCert').onclick = () => {
    const canvas = document.getElementById('certCanvas');
    const link = document.createElement('a');
    link.download = "nice-list-certificate.png";
    link.href = canvas.toDataURL();
    link.click();
};

document.getElementById('downloadPDF').onclick = () => {
    const canvas = document.getElementById('certCanvas');
    const imgData = canvas.toDataURL("image/png");
    const { jsPDF } = window.jspdf;
    const pdf = new jsPDF({ orientation: "landscape" });
    pdf.addImage(imgData, 'PNG', 10, 10, 280, 180);
    pdf.save("nice-list-certificate.pdf");
};

document.getElementById('printCert').onclick = () => {
    window.print();
};

// Snowfall generation
function createSnow(){
    const snow = document.createElement('div');
    snow.classList.add('snowflake');
    snow.style.left = Math.random() * window.innerWidth + 'px';
    snow.style.animationDuration = (Math.random() * 3 + 3) + 's';
    snow.style.opacity = Math.random();
    snow.style.fontSize = Math.random() * 10 + 10 + 'px';
    snow.innerHTML = "❄️";
    document.getElementById('snowOverlay').appendChild(snow);
    setTimeout(() => { snow.remove(); }, 6000);
}
setInterval(createSnow, 100);
