
let chatCount = 0;
const santaMessage = document.getElementById('santaMessage');
let selectedStyle = "warm";

function speakSanta(text){
    const utter = new SpeechSynthesisUtterance(text);
    utter.pitch = 0.9;
    utter.rate = 0.9;
    speechSynthesis.speak(utter);
}

document.getElementById('startChat').onclick = () => {
    document.getElementById('hero').classList.add('hidden');
    document.getElementById('chatScreen').classList.remove('hidden');
    speakSanta("Ho Ho Ho! Hello there! It's Santa!");
};

document.getElementById('nameFeature').onclick = () => {
    document.getElementById('hero').classList.add('hidden');
    document.getElementById('nameScreen').classList.remove('hidden');
};

document.querySelectorAll('.styleBtn').forEach(btn => {
    btn.onclick = () => {
        selectedStyle = btn.dataset.style;
    };
});

document.getElementById('playGreeting').onclick = () => {
    const name = document.getElementById('childName').value || "buddy";
    let message = "";

    if(selectedStyle === "warm"){
        message = `Ho Ho Ho, hello ${name}! Santa hopes you're having a wonderful day!`;
    } else if(selectedStyle === "excited"){
        message = `Ho Ho Ho! WOW! ${name}! Santa is so excited to talk to you!`;
    } else if(selectedStyle === "calm"){
        message = `Ho Ho Ho... hello ${name}. Santa wishes you a cozy and peaceful night.`;
    }

    speakSanta(message);
};

document.getElementById('userInput').addEventListener('keypress', function(e){
    if(e.key === 'Enter'){
        chatCount++;
        if(chatCount > 2){
            document.getElementById('upgradeModal').classList.remove('hidden');
            speakSanta("Ho Ho Ho! I would love to keep talking, but you'll need your grown-up's help!");
        } else {
            santaMessage.textContent = "Ho Ho Ho! Merry Christmas!";
            speakSanta("Ho Ho Ho! Merry Christmas!");
        }
        this.value = "";
    }
});

window.onload = () => {
    speechSynthesis.getVoices();
};
