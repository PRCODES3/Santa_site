
let chatCount = 0;
const santaMessage = document.getElementById('santaMessage');

function speakSanta(text){
    const utter = new SpeechSynthesisUtterance(text);
    utter.voice = speechSynthesis.getVoices().find(v => v.name.toLowerCase().includes("male")) || null;
    utter.pitch = 0.9;
    utter.rate = 0.9;
    speechSynthesis.speak(utter);
}

document.getElementById('startChat').onclick = () => {
    document.getElementById('hero').classList.add('hidden');
    document.getElementById('chatScreen').classList.remove('hidden');
    speakSanta("Ho Ho Ho! Hello there! It's Santa!");
};

document.getElementById('userInput').addEventListener('keypress', function(e){
    if(e.key === 'Enter'){
        chatCount++;
        if(chatCount > 2){
            document.getElementById('upgradeModal').classList.remove('hidden');
            speakSanta("Ho Ho Ho! I would love to keep talking, but you'll need your grown-up's help!");
        } else {
            santaMessage.textContent = "Ho Ho Ho! Merry Christmas!";
            speakSanta("Ho Ho Ho! Merry Christmas!");
        }
        this.value = "";
    }
});

window.onload = () => {
    // Preload voices
    speechSynthesis.getVoices();
};
